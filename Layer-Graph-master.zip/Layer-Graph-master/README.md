[![Maintainability](https://api.codeclimate.com/v1/badges/34003dec77cb92f19073/maintainability)](https://codeclimate.com/github/cK0nrad/Layer-Graph/maintainability)

# Layer-Graph
Real time layer 4 & 7 traffic.
# How to use it
Clone repository and set 'data/layer7-logs' to chmod 777.

Configuration avaible in 'config/config.php'.

#Konrad
